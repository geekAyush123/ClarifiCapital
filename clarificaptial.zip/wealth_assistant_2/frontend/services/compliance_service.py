from backend import WealthManagementAssistant

assistant = WealthManagementAssistant()

def update_compliance(enabled: bool) -> None:
    """Update compliance checking setting."""
    assistant.compliance_checked = enabled
    return None