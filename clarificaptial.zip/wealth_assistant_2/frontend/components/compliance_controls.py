import gradio as gr

def create_compliance_component():
    return gr.Markdown("### ⚖️ Compliance Controls"), gr.Checkbox(
        label="Enable Strict Compliance Checking",
        value=False,
        info="SEC/FINRA regulation checks"
    )