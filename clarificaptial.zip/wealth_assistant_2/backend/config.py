import os
from dotenv import load_dotenv

# Configuration
load_dotenv()

class Config:
    GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY", "AIzaSyD83yavELzObxwvUrQy8VyZcZ9-TzlFWlU")
    EMBEDDING_MODEL = "models/embedding-001"
    LLM_MODEL = "gemini-1.5-flash"
    LLM_TEMPERATURE = 0.3