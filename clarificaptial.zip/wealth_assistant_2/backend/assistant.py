from langchain_google_genai import GoogleGenerativeAIEmbeddings, ChatGoogleGenerativeAI
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import Chroma
from PyPDF2 import PdfReader
import os
import json
import pandas as pd
from typing import List, Dict, Tuple, Optional
from .config import Config
from .visualizations import WealthVisualizer
from .database import create_simulated_database
import plotly.graph_objects as go

wealth_db = create_simulated_database()

class WealthManagementAssistant:
    """Main wealth management assistant class."""
    
    def __init__(self):
        """Initialize the assistant with default settings."""
        self.vector_db = None
        self.uploaded_files = []
        self.compliance_checked = False
        self.text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=1000,
            chunk_overlap=200
        )
        self.embeddings = GoogleGenerativeAIEmbeddings(model=Config.EMBEDDING_MODEL)
        self.llm = ChatGoogleGenerativeAI(model=Config.LLM_MODEL, temperature=Config.LLM_TEMPERATURE)
        self.visualizer = WealthVisualizer()
        self.scope_description = """
        This assistant specializes in wealth management topics including:
        - Client portfolio analysis with visualizations
        - Risk assessment and metrics
        - Investment strategy and allocation
        - Market comparisons and benchmarking
        - Account-specific queries
        - Financial planning with charts
        - Performance analysis
        - Tax strategies
        - Estate planning
        """
    
    def extract_text_from_pdf(self, file_path: str) -> str:
        """Extract text from a PDF file."""
        try:
            with open(file_path, "rb") as f:
                reader = PdfReader(f)
                text = "\n".join([page.extract_text() for page in reader.pages if page.extract_text()])
            return text
        except Exception as e:
            print(f"Error reading PDF: {e}")
            return ""

    def process_uploaded_files(self, files: List[str]) -> Tuple[str, List[Dict[str, str]]]:
        """Process uploaded PDF files into a vector database."""
        if not files:
            return "No files uploaded", []

        docs = []
        metadatas = []
        successful_files = []
        
        for file_path in files:
            try:
                # Handle Gradio's file objects (they might be in temp storage)
                if isinstance(file_path, dict):
                    actual_path = file_path["name"]  # Gradio provides dictionary with "name" key
                else:
                    actual_path = file_path
                    
                text = self.extract_text_from_pdf(actual_path)
                if not text:
                    continue
                    
                chunks = self.text_splitter.split_text(text)
                docs.extend(chunks)
                metadatas.extend([{"source": actual_path}] * len(chunks))
                successful_files.append(os.path.basename(actual_path))
            except Exception as e:
                print(f"Error processing file {file_path}: {e}")
                continue

        if docs:
            try:
                self.vector_db = Chroma.from_texts(
                    docs,
                    self.embeddings,
                    metadatas=metadatas
                )
                return "Documents processed successfully!", [{"Document": f} for f in successful_files]
            except Exception as e:
                return f"Error creating vector database: {str(e)}", []
                
        return "No valid documents processed", []

    def check_compliance(self, message: str) -> bool:
        """Check if a message complies with regulations."""
        if not self.compliance_checked:
            return True

        prompt = f"""Analyze this wealth management query for compliance issues (SEC/FINRA):

        Query: {message}

        Identify regulatory concerns or privacy risks. Respond with ONLY "APPROVED" or "REJECTED: [reason]":"""

        try:
            response = self.llm.invoke(prompt).content
            return response.startswith("APPROVED")
        except Exception as e:
            print(f"Compliance check error: {e}")
            return True

    def is_in_scope(self, query: str) -> bool:
        """Check if the query falls within wealth management scope."""
        prompt = f"""Determine if this query falls within wealth management scope:

        Scope Description: {self.scope_description}

        Query: {query}

        Respond with ONLY "YES" or "NO":"""

        try:
            response = self.llm.invoke(prompt).content.strip().upper()
            return response == "YES"
        except Exception as e:
            print(f"Scope check error: {e}")
            return True

    def query_wealth_db(self, query: str) -> str:
        """Query the simulated wealth database."""
        db_context = f"""
        WEALTH DATABASE CONTEXT:
        {json.dumps(wealth_db, indent=2)}
        """

        prompt = f"""You are a wealth management AI with access to this database:
        {db_context}

        Analyze the following query and provide a detailed response with specific numbers:

        Query: {query}

        Response Guidelines:
        1. Always populate with client data when available
        2. Include relevant market data comparisons
        3. Highlight anomalies and opportunities
        4. Format numbers properly ($ and commas)
        5. Suggest next steps when appropriate
        6. Mention when visualizations would enhance understanding"""

        try:
            return self.llm.invoke(prompt).content
        except Exception as e:
            return f"Error querying database: {str(e)}"

    def query_documents(self, query: str) -> str:
        """Query uploaded documents if available."""
        if not self.vector_db:
            return ""

        try:
            docs = self.vector_db.similarity_search(query, k=3)
            context = "\n".join(f"DOCUMENT:\n{doc.page_content}" for doc in docs)
            return f"RELEVANT DOCUMENT EXCERPTS:\n{context}"
        except Exception as e:
            print(f"Error querying documents: {e}")
            return ""

    def generate_response(self, query: str) -> str:
        """Generate a comprehensive response combining DB and documents."""
        if not self.is_in_scope(query):
            return "This query is out of scope for wealth management assistance."

        if not self.check_compliance(query):
            return "COMPLIANCE REJECTION: This query cannot be processed due to regulatory concerns."

        db_response = self.query_wealth_db(query)
        doc_response = self.query_documents(query)

        if not doc_response:
            return db_response

        prompt = f"""Combine these responses into one coherent wealth management response:

        DATABASE ANALYSIS:
        {db_response}

        DOCUMENT ANALYSIS:
        {doc_response}

        Create a professional response that:
        1. Starts with most relevant information
        2. Integrates both sources seamlessly  
        3. Concludes with actionable next steps
        4. Notes when visualizations are available"""

        try:
            return self.llm.invoke(prompt).content
        except Exception as e:
            print(f"Response combination error: {e}")
            return db_response

    def get_client_visualizations(self, client_name: str) -> Tuple[Optional[go.Figure], ...]:
        """Get all visualizations for a client."""
        for cid, client in wealth_db["clients"].items():
            if client["name"].lower() == client_name.lower():
                return (
                    self.visualizer.create_portfolio_pie_chart(cid),
                    self.visualizer.create_sector_allocation_chart(cid),
                    self.visualizer.create_performance_comparison(cid),
                    self.visualizer.create_risk_metrics_radar(cid),
                    self.visualizer.create_account_breakdown_chart(cid)
                )
        return (None,) * 5
assistant = WealthManagementAssistant()