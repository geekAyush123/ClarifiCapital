from typing import List, Tuple
from backend import WealthManagementAssistant

assistant = WealthManagementAssistant()

def handle_chat(message: str, history: List[Tuple[str, str]]) -> Tuple[str, List[Tuple[str, str]]]:
    """Handle chat interactions."""
    history = history or []

    try:
        response = assistant.generate_response(message)
        history.append((message, response))
        return "", history
    except Exception as e:
        error_msg = f"Error: {str(e)}"
        history.append((message, error_msg))
        return "", history