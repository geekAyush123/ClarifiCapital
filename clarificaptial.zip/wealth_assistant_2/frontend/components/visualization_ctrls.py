import gradio as gr

def create_visualization_controls():
    header = gr.Markdown("### 📈 Quick Visualizations")
    dropdown = gr.Dropdown(
        choices=["John Smith", "Emily Davis"],
        label="Select Client",
        value="John Smith"
    )
    button = gr.Button("Generate Client Dashboard", variant="secondary")
    
    return header, dropdown, button