import warnings
from typing import List
import numpy as np
import pandas as pd

def setup_environment():
    """Configure environment settings."""
    warnings.filterwarnings("ignore")

def format_currency(value: float) -> str:
    """Format number as currency string."""
    return f"${value:,.2f}"

def generate_portfolio_values(base: float, count: int, volatility: float) -> List[float]:
    """Generate realistic portfolio values with trend and noise."""
    return [
        base + i*(base*0.005) + np.random.normal(0, volatility * base/100)
        for i in range(count)
    ]

def create_performance_dataframe(dates: pd.DatetimeIndex, portfolio: List[float], benchmark: List[float]) -> pd.DataFrame:
    """Create formatted performance DataFrame."""
    return pd.DataFrame({
        'Date': dates,
        'Portfolio': portfolio,
        'Benchmark': benchmark
    }).set_index('Date')