import gradio as gr

def create_chat_interface():
    return [
        gr.Markdown("### 💬 AI Wealth Advisor"),
        gr.Chatbot(height=400, show_label=False),
        gr.Textbox(
            label="Query",
            placeholder="Ask about portfolios, risk analysis, or request visualizations...",
            lines=2
        ),
        gr.Button("Send", variant="primary"),
        gr.Button("Clear Chat", variant="secondary")
    ]