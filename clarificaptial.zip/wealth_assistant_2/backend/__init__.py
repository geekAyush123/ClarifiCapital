from .assistant import WealthManagementAssistant
from .database import create_simulated_database
from .visualizations import WealthVisualizer

# Initialize core components
wealth_db = create_simulated_database()
visualizer = WealthVisualizer()
assistant = WealthManagementAssistant()

__all__ = [
    'WealthManagementAssistant',
    'WealthVisualizer',
    'wealth_db',
    'assistant',
    'visualizer'
]