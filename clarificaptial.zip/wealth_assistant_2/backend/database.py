import pandas as pd
import numpy as np
from typing import Dict, Any
from datetime import datetime

def create_simulated_database() -> Dict[str, Any]:
    """Create a comprehensive simulated wealth management database."""
    dates = pd.date_range(start='2023-01-01', end='2023-12-31', freq='ME')

    clients = {
        "client_001": {
            "name": "John Smith",
            "net_worth": 4500000,
            "risk_tolerance": "Moderate",
            "goals": ["Retirement at 60", "College fund for grandchildren"],
            "portfolio": {
                "stocks": 55,
                "bonds": 30,
                "alternatives": 10,
                "cash": 5
            },
            "accounts": [
                {"id": "acct_1", "type": "Brokerage", "balance": 2800000},
                {"id": "acct_2", "type": "IRA", "balance": 1200000},
                {"id": "acct_3", "type": "Trust", "balance": 500000}
            ],
            "advisors": ["Sarah Johnson", "Michael Chen"],
            "last_review": "2023-11-15",
            "historical_performance": {
                "dates": [d.strftime('%Y-%m-%d') for d in dates],
                "portfolio_values": [4200000 + i*25000 + np.random.normal(0, 50000) for i in range(len(dates))],
                "benchmark_values": [4200000 + i*20000 + np.random.normal(0, 40000) for i in range(len(dates))]
            },
            "sector_allocation": {
                "Technology": 25,
                "Healthcare": 15,
                "Financial Services": 12,
                "Consumer Discretionary": 10,
                "Energy": 8,
                "Utilities": 7,
                "Real Estate": 6,
                "Materials": 5,
                "Other": 12
            }
        },
        # ... rest of the client data ...
    }

    market_data = {
        "SP500": {"ytd_return": 12.4, "pe_ratio": 22.3, "volatility": 16.2},
        # ... rest of market data ...
    }

    risk_metrics = {
        "client_001": {
            "sharpe_ratio": 1.45,
            # ... rest of risk metrics ...
        }
    }

    return {"clients": clients, "market_data": market_data, "risk_metrics": risk_metrics}