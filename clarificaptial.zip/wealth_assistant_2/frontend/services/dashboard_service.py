import plotly.graph_objects as go
from typing import Optional, Tuple
from backend import WealthManagementAssistant

assistant = WealthManagementAssistant()

def generate_client_dashboard(client_name: str) -> Tuple[Optional[go.Figure], ...]:
    """Generate visualization dashboard for a client."""
    if not client_name:
        return (None,) * 6  # Now returns 6 elements
    
    client_viz = assistant.get_client_visualizations(client_name)
    market_viz = assistant.visualizer.create_market_comparison_dashboard()
    return client_viz + (market_viz,)  # Returns 6 figures total