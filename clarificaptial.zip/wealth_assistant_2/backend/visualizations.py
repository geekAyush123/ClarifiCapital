import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from typing import Optional, Tuple
from .database import create_simulated_database
import pandas as pd
wealth_db = create_simulated_database()

class WealthVisualizer:
    """Class for creating financial visualizations."""
    
    @staticmethod
    def create_portfolio_pie_chart(client_id: str) -> Optional[go.Figure]:
        """Create portfolio allocation pie chart."""
        if client_id not in wealth_db["clients"]:
            return None
            
        client = wealth_db["clients"][client_id]
        portfolio = client["portfolio"]

        fig = px.pie(
            values=list(portfolio.values()),
            names=list(portfolio.keys()),
            title=f"{client['name']} - Portfolio Allocation",
            color_discrete_sequence=px.colors.qualitative.Set3
        )
        fig.update_traces(textposition='inside', textinfo='percent+label')
        fig.update_layout(showlegend=True, height=400)
        return fig

    @staticmethod
    def create_sector_allocation_chart(client_id: str) -> Optional[go.Figure]:
        """Create sector allocation bar chart."""
        if client_id not in wealth_db["clients"]:
            return None
            
        client = wealth_db["clients"][client_id]
        if "sector_allocation" not in client:
            return None

        sectors = list(client["sector_allocation"].keys())
        allocations = list(client["sector_allocation"].values())

        fig = px.bar(
            x=allocations,
            y=sectors,
            orientation='h',
            title=f"{client['name']} - Sector Allocation",
            labels={'x': 'Allocation (%)', 'y': 'Sectors'},
            color=allocations,
            color_continuous_scale='viridis'
        )
        fig.update_layout(height=500, showlegend=False)
        return fig

    @staticmethod
    def create_performance_comparison(client_id: str) -> Optional[go.Figure]:
        """Create performance comparison line chart."""
        if client_id not in wealth_db["clients"]:
            return None
            
        client = wealth_db["clients"][client_id]
        if "historical_performance" not in client:
            return None

        hist_data = client["historical_performance"]
        dates = pd.to_datetime(hist_data["dates"])

        fig = go.Figure()

        # Portfolio performance
        fig.add_trace(go.Scatter(
            x=dates,
            y=hist_data["portfolio_values"],
            mode='lines',
            name='Portfolio',
            line=dict(color='blue', width=3)
        ))

        # Benchmark performance
        fig.add_trace(go.Scatter(
            x=dates,
            y=hist_data["benchmark_values"],
            mode='lines',
            name='Benchmark',
            line=dict(color='red', width=2, dash='dash')
        ))

        fig.update_layout(
            title=f"{client['name']} - Portfolio vs Benchmark Performance",
            xaxis_title="Date",
            yaxis_title="Portfolio Value ($)",
            hovermode='x unified',
            height=400
        )
        return fig

    @staticmethod
    def create_risk_metrics_radar(client_id: str) -> Optional[go.Figure]:
        """Create risk metrics radar chart."""
        if client_id not in wealth_db["risk_metrics"]:
            return None

        metrics = wealth_db["risk_metrics"][client_id]
        client_name = wealth_db["clients"][client_id]["name"]

        # Normalize metrics for radar chart (0-100 scale)
        categories = ['Sharpe Ratio', 'Alpha', 'Beta', 'Max Drawdown', 'Volatility']
        values = [
            min(metrics["sharpe_ratio"] * 30, 100),
            min(metrics["alpha"] * 20, 100),
            100 - abs(metrics["beta"] - 1) * 50,
            100 + metrics["max_drawdown"],
            max(100 - abs(metrics.get("volatility", 15)), 0)
        ]

        fig = go.Figure()
        fig.add_trace(go.Scatterpolar(
            r=values,
            theta=categories,
            fill='toself',
            name=client_name,
            line=dict(color='blue')
        ))

        fig.update_layout(
            polar=dict(radialaxis=dict(visible=True, range=[0, 100])),
            showlegend=True,
            title=f"{client_name} - Risk Profile Analysis",
            height=400
        )
        return fig
        
    @staticmethod
    def create_account_breakdown_chart(client_id: str) -> Optional[go.Figure]:
        """Create account breakdown chart."""
        if client_id not in wealth_db["clients"]:
            return None
            
        client = wealth_db["clients"][client_id]
        accounts = client["accounts"]

        account_types = [acc["type"] for acc in accounts]
        balances = [acc["balance"] for acc in accounts]

        fig = px.bar(
            x=account_types,
            y=balances,
            title=f"{client['name']} - Account Breakdown",
            labels={'x': 'Account Type', 'y': 'Balance ($)'},
            color=balances,
            color_continuous_scale='blues'
        )

        fig.update_layout(
            yaxis_tickformat='$,.0f',
            height=400,
            showlegend=False
        )
        return fig

    @staticmethod
    def create_market_comparison_dashboard() -> go.Figure:
        """Create market comparison dashboard."""
        market_data = wealth_db["market_data"]
        fig = make_subplots(
            rows=2, cols=2,
            subplot_titles=('YTD Returns', 'Risk Metrics', 'Valuations', 'Yields'),
            specs=[[{"type": "bar"}, {"type": "bar"}],
                   [{"type": "scatter"}, {"type": "bar"}]]
        )

        # YTD Returns
        assets = list(market_data.keys())
        returns = [market_data[asset]["ytd_return"] for asset in assets]
        fig.add_trace(
            go.Bar(x=assets, y=returns, name="YTD Return (%)", marker_color='lightblue'),
            row=1, col=1
        )

        # Risk Metrics
        volatilities = [market_data[asset].get("volatility", 0) for asset in assets]
        fig.add_trace(
            go.Bar(x=assets, y=volatilities, name="Volatility (%)", marker_color='lightcoral'),
            row=1, col=2
        )

        # Risk-Return Scatter
        fig.add_trace(
            go.Scatter(
                x=volatilities,
                y=returns,
                mode='markers+text',
                text=assets,
                name="Risk-Return",
                marker=dict(size=12, color='green')
            ),
            row=2, col=1
        )

        # Yields/Rates
        yields = [
            market_data["SP500"]["pe_ratio"],
            market_data["Bonds"]["yield"],
            market_data["RealEstate"]["cap_rate"],
            0  # Commodities don't have yield
        ]
        fig.add_trace(
            go.Bar(x=assets, y=yields, name="Yields/Ratios", marker_color='gold'),
            row=2, col=2
        )

        fig.update_layout(height=600, showlegend=False, title_text="Market Overview Dashboard")
        return fig