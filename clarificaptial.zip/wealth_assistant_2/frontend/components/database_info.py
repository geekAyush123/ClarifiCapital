import gradio as gr
import pandas as pd

def create_db_info_component():
    return gr.Markdown("### 📊 Client Database"), gr.Dataframe(
        value=pd.DataFrame([
            {"Client": "John Smith", "Net Worth": "$4.5M", "Risk": "Moderate", "Accounts": "3"},
            {"Client": "Emily Davis", "Net Worth": "$2.2M", "Risk": "Conservative", "Accounts": "2"}
        ]),
        interactive=False
    )