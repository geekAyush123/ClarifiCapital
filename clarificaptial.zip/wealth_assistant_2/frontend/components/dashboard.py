import gradio as gr

def create_dashboard_components():
    with gr.Tab("Client Portfolio Analysis"):
        with gr.Row():
            portfolio_plot = gr.Plot(label="Portfolio Allocation")
            sector_plot = gr.Plot(label="Sector Breakdown")

        with gr.Row():
            performance_plot = gr.Plot(label="Performance vs Benchmark")
            risk_plot = gr.Plot(label="Risk Profile")

        account_plot = gr.Plot(label="Account Breakdown")

    with gr.Tab("Market Overview"):
        market_dashboard = gr.Plot(label="Market Analysis Dashboard")

    return [
        portfolio_plot, sector_plot,
        performance_plot, risk_plot, 
        account_plot, market_dashboard
    ]