from dataclasses import dataclass
from typing import Optional, Dict, Any, List

@dataclass
class DocumentProcessingResult:
    """Result of document processing operation."""
    status: str
    processed_file: Optional[Dict[str, Any]]
    error: Optional[str] = None

@dataclass
class ClientQueryResult:
    """Result of client query operation."""
    status: str
    data: Optional[Dict[str, Any]]
    error: Optional[str] = None
    visualizations: Optional[Dict[str, Any]] = None

@dataclass
class VisualizationResult:
    """Result of visualization generation."""
    status: str
    figures: Optional[Dict[str, Any]]
    error: Optional[str] = None