import gradio as gr

def create_document_upload_component():
    return [
        gr.Markdown("### 📂 Document Analysis"),
        gr.File(file_count="multiple", file_types=[".pdf"], type="filepath"),  # Add type="filepath"
        gr.Button("Process Documents", variant="primary"),
        gr.Textbox(label="Upload Status", interactive=False),
        gr.Dataframe(headers=["Document"], interactive=False)
    ]