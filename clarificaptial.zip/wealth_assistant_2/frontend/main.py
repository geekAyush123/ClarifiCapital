import sys
from pathlib import Path

# Add the root directory to Python path
root_dir = str(Path(__file__).parent.parent)
if root_dir not in sys.path:
    sys.path.insert(0, root_dir)

import gradio as gr
from frontend.components import (
    database_info, document_analysis, 
    compliance_controls, visualization_ctrls,
    chat_interface, dashboard
)
from frontend.services import (
    chat_service, compliance_service,
    dashboard_service
)
from backend.assistant import assistant  
import pandas as pd
from typing import List, Tuple, Optional, Dict
import plotly.graph_objects as go

def create_app():
    with gr.Blocks(title="Wealth Management AI", theme="soft") as demo:
        gr.Markdown("""
        # 🏦 Enhanced Wealth Management AI Assistant
        *Advanced analytics with interactive visualizations and comprehensive client insights*
        """)

        with gr.Row():
            with gr.Column(scale=1):
                # Left sidebar components
                db_title, db_preview = database_info.create_db_info_component()
                doc_components = document_analysis.create_document_upload_component()
                comp_title, comp_toggle = compliance_controls.create_compliance_component()
                viz_components = visualization_ctrls.create_visualization_controls()

            with gr.Column(scale=2):
                # Right main components
                chat_components = chat_interface.create_chat_interface()
                
                # Example Queries
                gr.Markdown("### 💡 Example Queries")
                gr.Examples(
                    examples=[
                        "Show me John Smith's complete portfolio analysis with charts",
                        "Compare Emily Davis' risk metrics to market benchmarks",
                        "Create a performance comparison for both clients",
                        "Generate sector allocation analysis for John Smith",
                        "What are the key risk factors in Emily's portfolio?",
                        "Show market overview dashboard"
                    ],
                    inputs=chat_components[2]  # msg Textbox
                )

        # Dashboard components
        gr.Markdown("## 📊 Interactive Analytics Dashboard")
        dash_components = dashboard.create_dashboard_components()

        # Connect components
        doc_components[2].click(
            assistant.process_uploaded_files,
            inputs=doc_components[1],
            outputs=[doc_components[3], doc_components[4]]
        )

        comp_toggle.change(
            compliance_service.update_compliance,
            inputs=comp_toggle,
            outputs=[]
        )

        viz_components[2].click(
            dashboard_service.generate_client_dashboard,
            inputs=viz_components[1],  # The dropdown
            outputs=dash_components  # All 6 components
        )

        chat_components[3].click(  # Submit button
            chat_service.handle_chat,
            inputs=[chat_components[2], chat_components[1]],  # msg, chatbot
            outputs=[chat_components[2], chat_components[1]]  # msg, chatbot
        )

        chat_components[2].submit(  # Textbox submit
            chat_service.handle_chat,
            inputs=[chat_components[2], chat_components[1]],
            outputs=[chat_components[2], chat_components[1]]
        )

        chat_components[4].click(  # Clear button
            lambda: ([], ""),
            outputs=[chat_components[1], chat_components[2]]
        )

        return demo

if __name__ == "__main__":
    app = create_app()
    app.launch(share=True, debug=True)